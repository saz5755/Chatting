using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;

public class ChattingMessage : MonoBehaviour
{
    [SerializeField] private Image imgBackground;
    [SerializeField] private Text txtNickname;
    [SerializeField] private Text txtMessage;

    public void WriteMessage(Player player, string message)
    {
        txtNickname.text = player.NickName;
        txtMessage.text = message;

        if (player == PhotonNetwork.LocalPlayer)    // �� �ڽ����� Ȯ��
        {
            imgBackground.color = new Color(.9f, .9f, .9f);
        }     
    }


}
