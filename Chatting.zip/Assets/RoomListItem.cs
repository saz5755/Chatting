using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using TMPro;
using Photon.Pun;
using Photon.Realtime;

public class RoomListItem : MonoBehaviour
{
    [SerializeField] private Text txtRoomName;

    public void Init(RoomInfo info)
    {
        Refresh(info);
        // �� �̸� �� �̸� �� �̹�
        //         2 / 16
    }

    public void Refresh(RoomInfo info)
    {
        txtRoomName.text = $"{info.Name}\n{info.PlayerCount} / {info.MaxPlayers}";

        GetComponent<Button>().onClick.RemoveAllListeners();
        GetComponent<Button>().onClick.AddListener(() =>
        {
            PhotonNetwork.JoinRoom(info.Name);
        });
    }
}
