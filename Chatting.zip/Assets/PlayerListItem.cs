using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Realtime;

public class PlayerListItem : MonoBehaviour
{
    [SerializeField] private Text txtNickname;

    public void Init(Player player)
    {
        Refresh(player);
    }

    public void Refresh(Player player)
    {
        txtNickname.text = player.NickName;
    }
}
