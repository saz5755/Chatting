using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;
public class ChattingManager : MonoBehaviourPun, IPunObservable
{
    [SerializeField] private Transform chattingParent;

    private GameObject chttaingPrefab;

    [SerializeField] private InputField inputMessage;

    [SerializeField] private Button btnSend;

    private void Awake()
    {
        chttaingPrefab = Resources.Load<GameObject>("ChattingMessage");
        btnSend.onClick.AddListener(MessageSend);
    }

    private void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (inputMessage.IsActive())
            {
                MessageSend();
            }
        }
    }

    private void MessageSend()
    {
        photonView.RPC("MessageRecieve", RpcTarget.All, PhotonNetwork.LocalPlayer, inputMessage.text);  //RpcTarget.All ��ȿ� ���
        inputMessage.text = "";            //�ʱ�ȭ 
        inputMessage.ActivateInputField(); //�ٷ� �Է°����ϰ� Ȱ��ȭ
    }

    [PunRPC]    //������ �����ϴ� �Լ���� ����
    private void MessageRecieve(Player who, string message)
    {
        CreateMessage(who, message);
    }

    private void CreateMessage(Player who, string message)
    {
        ChattingMessage chat = Instantiate(chttaingPrefab, chattingParent).GetComponent<ChattingMessage>();
        chat.WriteMessage(who, message);

        StartCoroutine(AutoScroll());
    }

    IEnumerator AutoScroll()
    {
        yield return new WaitForEndOfFrame();
        float height = chattingParent.GetComponent<RectTransform>().rect.height;

        chattingParent.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, height);
    }

    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {


    }
}
